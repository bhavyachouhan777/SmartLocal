import { View, Text, StyleSheet, ScrollView, useColorScheme, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useLocation } from '@/hooks/useLocation';
import { useTrains } from '@/hooks/useTrains';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { StationHeader } from '@/components/feature/StationHeader';
import { AIAssistantCard } from '@/components/feature/AIAssistantCard';
import { AISuggestionBanner } from '@/components/feature/AISuggestionBanner';
import { TrainCard } from '@/components/feature/TrainCard';
import { colors, spacing, typography } from '@/constants/theme';
import { useAlert } from '@/template';

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const insets = useSafeAreaInsets();
  const { showAlert } = useAlert();

  const { nearestStation, loading: locationLoading, error: locationError, refreshLocation } = useLocation();
  const {
    trains,
    aiSuggestion,
    loadingSuggestion,
    suggestionError,
    getAISuggestion,
    refresh: refreshTrains,
  } = useTrains(nearestStation?.name || '', nearestStation?.line || 'Central');

  const handleRefresh = () => {
    refreshLocation();
    refreshTrains();
  };

  const handleGetSuggestion = (destination: string, isRunningLate: boolean) => {
    getAISuggestion(destination, isRunningLate);
  };

  if (locationLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background[isDark ? 'dark' : 'light'] }]}>
        <LoadingSpinner message="Finding nearest station..." />
      </View>
    );
  }

  if (locationError || !nearestStation) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background[isDark ? 'dark' : 'light'] }]}>
        <View style={styles.errorContainer}>
          <Text style={[styles.errorText, { color: colors.text.primary[isDark ? 'dark' : 'light'] }]}>
            {locationError || 'Unable to find nearest station'}
          </Text>
          <Text style={[styles.errorHint, { color: colors.text.secondary[isDark ? 'dark' : 'light'] }]}>
            Please enable location services
          </Text>
        </View>
      </View>
    );
  }

  if (suggestionError) {
    showAlert('AI Suggestion Error', suggestionError);
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background[isDark ? 'dark' : 'light'] }]}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: Platform.select({ ios: insets.top, android: insets.top, default: 0 }),
            paddingBottom: Math.max(insets.bottom, spacing.md),
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <StationHeader station={nearestStation} onRefresh={handleRefresh} />
        
        <AIAssistantCard onGetSuggestion={handleGetSuggestion} loading={loadingSuggestion} />

        {aiSuggestion && <AISuggestionBanner suggestion={aiSuggestion} />}

        <View style={styles.scheduleSection}>
          <Text style={[styles.sectionTitle, { color: colors.text.primary[isDark ? 'dark' : 'light'] }]}>
            Upcoming Trains
          </Text>
          {trains.map((train) => (
            <TrainCard
              key={train.id}
              train={train}
              isAISuggested={train.id === aiSuggestion?.trainId}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: spacing.xl,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    gap: spacing.sm,
  },
  errorText: {
    ...typography.headline,
    textAlign: 'center',
  },
  errorHint: {
    ...typography.callout,
    textAlign: 'center',
  },
  scheduleSection: {
    marginTop: spacing.lg,
    paddingHorizontal: spacing.md,
    gap: spacing.xs,
  },
  sectionTitle: {
    ...typography.title3,
    marginBottom: spacing.sm,
  },
});
