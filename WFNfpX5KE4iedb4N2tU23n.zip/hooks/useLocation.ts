import { useState, useEffect } from 'react';
import * as Location from 'expo-location';
import { Station, findNearestStation } from '@/constants/stations';

export const useLocation = () => {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [nearestStation, setNearestStation] = useState<Station | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    requestLocation();
  }, []);

  const requestLocation = async () => {
    try {
      setLoading(true);
      setError(null);

      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setError('Location permission denied');
        setLoading(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      setLocation(loc);

      const nearest = findNearestStation(loc.coords.latitude, loc.coords.longitude);
      setNearestStation(nearest);
      setLoading(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to get location');
      setLoading(false);
    }
  };

  const refreshLocation = () => {
    requestLocation();
  };

  return {
    location,
    nearestStation,
    loading,
    error,
    refreshLocation,
  };
};
