import { useState, useEffect } from 'react';
import { Train, getTrainSchedule } from '@/services/trainService';
import { AISuggestion, getAITrainSuggestion } from '@/services/aiService';
import { TrainLine } from '@/constants/stations';

export const useTrains = (stationName: string, line: TrainLine) => {
  const [trains, setTrains] = useState<Train[]>([]);
  const [aiSuggestion, setAiSuggestion] = useState<AISuggestion | null>(null);
  const [loadingSuggestion, setLoadingSuggestion] = useState(false);
  const [suggestionError, setSuggestionError] = useState<string | null>(null);

  useEffect(() => {
    if (stationName) {
      loadTrains();
    }
  }, [stationName, line]);

  const loadTrains = () => {
    const schedule = getTrainSchedule(stationName, line);
    setTrains(schedule);
  };

  const getAISuggestion = async (destination: string, isRunningLate: boolean = false) => {
    if (trains.length === 0) {
      setSuggestionError('No trains available');
      return;
    }

    setLoadingSuggestion(true);
    setSuggestionError(null);

    const { suggestion, error } = await getAITrainSuggestion(
      stationName,
      destination,
      trains,
      isRunningLate
    );

    if (error) {
      setSuggestionError(error);
      setAiSuggestion(null);
    } else {
      setAiSuggestion(suggestion);
    }

    setLoadingSuggestion(false);
  };

  const refresh = () => {
    loadTrains();
    setAiSuggestion(null);
    setSuggestionError(null);
  };

  return {
    trains,
    aiSuggestion,
    loadingSuggestion,
    suggestionError,
    getAISuggestion,
    refresh,
  };
};
