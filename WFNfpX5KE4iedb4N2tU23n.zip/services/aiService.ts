import { getSupabaseClient } from '@/template';
import { Train } from './trainService';

export interface AISuggestion {
  trainId: string;
  reason: string;
  confidence: 'high' | 'medium' | 'low';
}

export const getAITrainSuggestion = async (
  currentStation: string,
  destination: string,
  trains: Train[],
  isRunningLate: boolean = false
): Promise<{ suggestion: AISuggestion | null; error: string | null }> => {
  try {
    const supabase = getSupabaseClient();
    
    const currentTime = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    
    const trainList = trains.slice(0, 5).map((t, idx) => 
      `${idx + 1}. ${t.departureTime} to ${t.destination} (Platform ${t.platform})${t.isFast ? ' - FAST' : ' - LOCAL'}${t.isDelayed ? ` - DELAYED ${t.delayMinutes}min` : ''}`
    ).join('\n');
    
    const prompt = isRunningLate
      ? `You are an expert Mumbai local train assistant. A passenger is RUNNING LATE at ${currentStation} station.

Current time: ${currentTime}
Destination: ${destination}
Available trains:
${trainList}

They missed their planned train! Suggest the BEST alternative considering:
- Next fastest option (FAST trains preferred)
- Avoid heavily delayed trains
- Platform accessibility
- Connection options if needed

Respond in this EXACT JSON format:
{
  "trainId": "number from 1-5",
  "reason": "Brief explanation (max 80 characters)",
  "confidence": "high or medium or low"
}`
      : `You are an expert Mumbai local train assistant helping a passenger at ${currentStation} station.

Current time: ${currentTime}
Destination: ${destination}
Available trains:
${trainList}

Suggest the BEST train considering:
- Travel time (FAST vs LOCAL)
- Delay status
- Platform convenience
- Departure timing

Respond in this EXACT JSON format:
{
  "trainId": "number from 1-5",
  "reason": "Brief explanation (max 80 characters)",
  "confidence": "high or medium or low"
}`;

    const { data, error } = await supabase.functions.invoke('ai-train-suggestion', {
      body: { prompt },
    });

    if (error) {
      throw error;
    }

    if (!data || !data.suggestion) {
      throw new Error('Invalid AI response');
    }

    const trainIndex = parseInt(data.suggestion.trainId) - 1;
    if (trainIndex < 0 || trainIndex >= trains.length) {
      throw new Error('Invalid train selection');
    }

    return {
      suggestion: {
        trainId: trains[trainIndex].id,
        reason: data.suggestion.reason,
        confidence: data.suggestion.confidence,
      },
      error: null,
    };
  } catch (err) {
    return {
      suggestion: null,
      error: err instanceof Error ? err.message : 'Failed to get AI suggestion',
    };
  }
};
