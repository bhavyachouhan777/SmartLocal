import { TrainLine } from '@/constants/stations';

export interface Train {
  id: string;
  destination: string;
  departureTime: string;
  platform: string;
  isFast: boolean;
  isDelayed: boolean;
  delayMinutes?: number;
  line: TrainLine;
}

// Mock train schedule generator
export const getTrainSchedule = (stationName: string, line: TrainLine): Train[] => {
  const now = new Date();
  const trains: Train[] = [];
  
  const destinations = getDestinations(line);
  
  for (let i = 0; i < 10; i++) {
    const time = new Date(now.getTime() + i * 8 * 60000); // Every 8 minutes
    const isFast = Math.random() > 0.6;
    const isDelayed = Math.random() > 0.8;
    const delayMinutes = isDelayed ? Math.floor(Math.random() * 15) + 5 : 0;
    
    trains.push({
      id: `${line}-${i}`,
      destination: destinations[Math.floor(Math.random() * destinations.length)],
      departureTime: formatTime(time),
      platform: `${Math.floor(Math.random() * 6) + 1}`,
      isFast,
      isDelayed,
      delayMinutes: isDelayed ? delayMinutes : undefined,
      line,
    });
  }
  
  return trains;
};

const getDestinations = (line: TrainLine): string[] => {
  switch (line) {
    case 'Central':
      return ['Thane', 'Kalyan', 'Kasara', 'Khopoli', 'Karjat'];
    case 'Western':
      return ['Borivali', 'Virar', 'Dahanu Road', 'Churchgate'];
    case 'Harbour':
      return ['Panvel', 'Vashi', 'Nerul', 'Belapur', 'CSMT'];
  }
};

const formatTime = (date: Date): string => {
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  return `${displayHours}:${minutes.toString().padStart(2, '0')} ${ampm}`;
};
