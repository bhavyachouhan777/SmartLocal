import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Train } from '@/services/trainService';
import { getLineColor } from '@/constants/stations';
import { colors, spacing, typography, borderRadius } from '@/constants/theme';

interface TrainCardProps {
  train: Train;
  isAISuggested?: boolean;
}

export const TrainCard = ({ train, isAISuggested }: TrainCardProps) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: colors.card[isDark ? 'dark' : 'light'] },
        isAISuggested && styles.suggestedContainer,
      ]}
    >
      <View style={[styles.lineIndicator, { backgroundColor: getLineColor(train.line) }]} />
      
      <View style={styles.content}>
        <View style={styles.timeRow}>
          <Text style={[styles.time, { color: colors.text.primary[isDark ? 'dark' : 'light'] }]}>
            {train.departureTime}
          </Text>
          {isAISuggested && (
            <View style={styles.suggestedBadge}>
              <Ionicons name="star" size={14} color="#FFFFFF" />
              <Text style={styles.suggestedText}>AI Pick</Text>
            </View>
          )}
        </View>

        <View style={styles.detailsRow}>
          <View style={styles.destination}>
            <Ionicons
              name="arrow-forward"
              size={16}
              color={colors.text.secondary[isDark ? 'dark' : 'light']}
            />
            <Text style={[styles.destinationText, { color: colors.text.primary[isDark ? 'dark' : 'light'] }]}>
              {train.destination}
            </Text>
          </View>

          <View style={styles.badges}>
            {train.isFast && (
              <View style={[styles.badge, { backgroundColor: colors.success }]}>
                <Text style={styles.badgeText}>FAST</Text>
              </View>
            )}
            {train.isDelayed && (
              <View style={[styles.badge, { backgroundColor: colors.danger }]}>
                <Text style={styles.badgeText}>+{train.delayMinutes}min</Text>
              </View>
            )}
          </View>
        </View>

        <View style={styles.platformRow}>
          <Ionicons name="train" size={14} color={colors.text.tertiary[isDark ? 'dark' : 'light']} />
          <Text style={[styles.platformText, { color: colors.text.tertiary[isDark ? 'dark' : 'light'] }]}>
            Platform {train.platform}
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    borderRadius: borderRadius.lg,
    overflow: 'hidden',
    marginBottom: spacing.sm,
  },
  suggestedContainer: {
    borderWidth: 2,
    borderColor: colors.primary,
  },
  lineIndicator: {
    width: 4,
  },
  content: {
    flex: 1,
    padding: spacing.md,
    gap: spacing.xs,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  time: {
    ...typography.title3,
    fontWeight: '700',
  },
  suggestedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
  },
  suggestedText: {
    ...typography.caption1,
    color: '#FFFFFF',
    fontWeight: '700',
  },
  detailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  destination: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    flex: 1,
  },
  destinationText: {
    ...typography.body,
    fontWeight: '500',
  },
  badges: {
    flexDirection: 'row',
    gap: spacing.xs,
  },
  badge: {
    paddingHorizontal: spacing.xs,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
  },
  badgeText: {
    ...typography.caption1,
    color: '#FFFFFF',
    fontWeight: '700',
  },
  platformRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  platformText: {
    ...typography.footnote,
  },
});
