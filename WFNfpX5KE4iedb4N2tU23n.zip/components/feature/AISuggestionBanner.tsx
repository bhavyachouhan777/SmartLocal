import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, typography, borderRadius } from '@/constants/theme';
import { AISuggestion } from '@/services/aiService';

interface AISuggestionBannerProps {
  suggestion: AISuggestion;
}

export const AISuggestionBanner = ({ suggestion }: AISuggestionBannerProps) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'high':
        return colors.success;
      case 'medium':
        return colors.warning;
      case 'low':
        return colors.danger;
      default:
        return colors.text.secondary[isDark ? 'dark' : 'light'];
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: 'rgba(0, 122, 255, 0.1)' }]}>
      <View style={styles.header}>
        <Ionicons name="bulb" size={20} color={colors.primary} />
        <Text style={[styles.title, { color: colors.primary }]}>AI Recommendation</Text>
        <View style={[styles.confidenceBadge, { backgroundColor: getConfidenceColor(suggestion.confidence) }]}>
          <Text style={styles.confidenceText}>{suggestion.confidence.toUpperCase()}</Text>
        </View>
      </View>
      <Text style={[styles.reason, { color: colors.text.primary[isDark ? 'dark' : 'light'] }]}>
        {suggestion.reason}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    gap: spacing.xs,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  title: {
    ...typography.callout,
    fontWeight: '600',
    flex: 1,
  },
  confidenceBadge: {
    paddingHorizontal: spacing.xs,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
  },
  confidenceText: {
    ...typography.caption2,
    color: '#FFFFFF',
    fontWeight: '700',
  },
  reason: {
    ...typography.subhead,
    marginLeft: 28,
  },
});
