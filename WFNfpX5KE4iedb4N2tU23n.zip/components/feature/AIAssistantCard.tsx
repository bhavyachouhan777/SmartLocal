import { View, Text, TouchableOpacity, StyleSheet, useColorScheme, TextInput, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, typography, borderRadius } from '@/constants/theme';

interface AIAssistantCardProps {
  onGetSuggestion: (destination: string, isRunningLate: boolean) => void;
  loading: boolean;
}

export const AIAssistantCard = ({ onGetSuggestion, loading }: AIAssistantCardProps) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const [destination, setDestination] = useState('');
  const [isLateMode, setIsLateMode] = useState(false);

  const handleGetSuggestion = () => {
    if (destination.trim()) {
      onGetSuggestion(destination.trim(), isLateMode);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.card[isDark ? 'dark' : 'light'] }]}>
      <View style={styles.header}>
        <View style={styles.titleRow}>
          <Ionicons name="sparkles" size={20} color={colors.primary} />
          <Text style={[styles.title, { color: colors.text.primary[isDark ? 'dark' : 'light'] }]}>
            AI Assistant
          </Text>
        </View>
      </View>

      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: colors.surface[isDark ? 'dark' : 'light'],
            color: colors.text.primary[isDark ? 'dark' : 'light'],
            borderColor: colors.border[isDark ? 'dark' : 'light'],
          },
        ]}
        placeholder="Where are you going?"
        placeholderTextColor={colors.text.tertiary[isDark ? 'dark' : 'light']}
        value={destination}
        onChangeText={setDestination}
        editable={!loading}
      />

      <TouchableOpacity
        style={[
          styles.lateButton,
          isLateMode && styles.lateButtonActive,
          { borderColor: colors.border[isDark ? 'dark' : 'light'] },
        ]}
        onPress={() => setIsLateMode(!isLateMode)}
        disabled={loading}
      >
        <Ionicons
          name={isLateMode ? 'checkmark-circle' : 'time-outline'}
          size={20}
          color={isLateMode ? colors.warning : colors.text.secondary[isDark ? 'dark' : 'light']}
        />
        <Text
          style={[
            styles.lateButtonText,
            { color: isLateMode ? colors.warning : colors.text.secondary[isDark ? 'dark' : 'light'] },
          ]}
        >
          Running Late?
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[
          styles.suggestButton,
          { backgroundColor: colors.primary },
          (!destination.trim() || loading) && styles.suggestButtonDisabled,
        ]}
        onPress={handleGetSuggestion}
        disabled={!destination.trim() || loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <>
            <Ionicons name="flash" size={20} color="#FFFFFF" />
            <Text style={styles.suggestButtonText}>Get Smart Suggestion</Text>
          </>
        )}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    gap: spacing.sm,
  },
  header: {
    marginBottom: spacing.xs,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  title: {
    ...typography.headline,
  },
  input: {
    ...typography.body,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    borderWidth: 1,
  },
  lateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    borderWidth: 1,
  },
  lateButtonActive: {
    backgroundColor: 'rgba(255, 149, 0, 0.1)',
    borderColor: 'transparent',
  },
  lateButtonText: {
    ...typography.callout,
    fontWeight: '600',
  },
  suggestButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
  },
  suggestButtonDisabled: {
    opacity: 0.5,
  },
  suggestButtonText: {
    ...typography.callout,
    color: '#FFFFFF',
    fontWeight: '600',
  },
});
