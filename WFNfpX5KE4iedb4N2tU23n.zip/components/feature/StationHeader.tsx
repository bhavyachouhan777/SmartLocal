import { View, Text, TouchableOpacity, StyleSheet, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Station, getLineColor } from '@/constants/stations';
import { colors, spacing, typography, borderRadius } from '@/constants/theme';

interface StationHeaderProps {
  station: Station;
  onRefresh: () => void;
}

export const StationHeader = ({ station, onRefresh }: StationHeaderProps) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <View style={[styles.container, { backgroundColor: colors.card[isDark ? 'dark' : 'light'] }]}>
      <View style={styles.content}>
        <View style={styles.stationInfo}>
          <View style={[styles.lineBadge, { backgroundColor: getLineColor(station.line) }]}>
            <Text style={styles.lineBadgeText}>{station.line}</Text>
          </View>
          <View style={styles.stationText}>
            <Text style={[styles.stationName, { color: colors.text.primary[isDark ? 'dark' : 'light'] }]}>
              {station.name}
            </Text>
            <View style={styles.locationRow}>
              <Ionicons name="location" size={14} color={colors.text.secondary[isDark ? 'dark' : 'light']} />
              <Text style={[styles.locationText, { color: colors.text.secondary[isDark ? 'dark' : 'light'] }]}>
                Nearest Station
              </Text>
            </View>
          </View>
        </View>
        <TouchableOpacity style={styles.refreshButton} onPress={onRefresh}>
          <Ionicons name="refresh" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  stationInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: spacing.sm,
  },
  lineBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
  },
  lineBadgeText: {
    ...typography.caption1,
    color: '#FFFFFF',
    fontWeight: '700',
  },
  stationText: {
    flex: 1,
    gap: spacing.xs,
  },
  stationName: {
    ...typography.headline,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationText: {
    ...typography.footnote,
  },
  refreshButton: {
    padding: spacing.sm,
  },
});
