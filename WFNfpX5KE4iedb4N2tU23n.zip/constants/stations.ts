export type TrainLine = 'Central' | 'Western' | 'Harbour';

export interface Station {
  id: string;
  name: string;
  line: TrainLine;
  latitude: number;
  longitude: number;
}

export const MUMBAI_STATIONS: Station[] = [
  // Central Line
  { id: 'csmt', name: 'Chhatrapati Shivaji Maharaj Terminus', line: 'Central', latitude: 18.9398, longitude: 72.8355 },
  { id: 'masjid', name: 'Masjid', line: 'Central', latitude: 18.9476, longitude: 72.8313 },
  { id: 'sandhurst', name: 'Sandhurst Road', line: 'Central', latitude: 18.9518, longitude: 72.8308 },
  { id: 'byculla', name: 'Byculla', line: 'Central', latitude: 18.9794, longitude: 72.8322 },
  { id: 'chinchpokli', name: 'Chinchpokli', line: 'Central', latitude: 18.9909, longitude: 72.8311 },
  { id: 'currey', name: 'Currey Road', line: 'Central', latitude: 19.0062, longitude: 72.8314 },
  { id: 'parel', name: 'Parel', line: 'Central', latitude: 19.0118, longitude: 72.8384 },
  { id: 'dadar', name: 'Dadar', line: 'Central', latitude: 19.0176, longitude: 72.8432 },
  { id: 'matunga', name: 'Matunga', line: 'Central', latitude: 19.0270, longitude: 72.8465 },
  { id: 'sion', name: 'Sion', line: 'Central', latitude: 19.0433, longitude: 72.8612 },
  { id: 'kurla', name: 'Kurla', line: 'Central', latitude: 19.0676, longitude: 72.8798 },
  { id: 'ghatkopar', name: 'Ghatkopar', line: 'Central', latitude: 19.0864, longitude: 72.9081 },
  { id: 'thane', name: 'Thane', line: 'Central', latitude: 19.1870, longitude: 72.9780 },
  
  // Western Line
  { id: 'churchgate', name: 'Churchgate', line: 'Western', latitude: 18.9354, longitude: 72.8274 },
  { id: 'marine', name: 'Marine Lines', line: 'Western', latitude: 18.9450, longitude: 72.8232 },
  { id: 'charni', name: 'Charni Road', line: 'Western', latitude: 18.9525, longitude: 72.8192 },
  { id: 'grant', name: 'Grant Road', line: 'Western', latitude: 18.9630, longitude: 72.8150 },
  { id: 'mumbai', name: 'Mumbai Central', line: 'Western', latitude: 18.9685, longitude: 72.8195 },
  { id: 'mahalaxmi', name: 'Mahalaxmi', line: 'Western', latitude: 18.9827, longitude: 72.8229 },
  { id: 'lower', name: 'Lower Parel', line: 'Western', latitude: 18.9967, longitude: 72.8264 },
  { id: 'elphinstone', name: 'Elphinstone Road', line: 'Western', latitude: 18.9998, longitude: 72.8319 },
  { id: 'dadarw', name: 'Dadar', line: 'Western', latitude: 19.0176, longitude: 72.8432 },
  { id: 'bandra', name: 'Bandra', line: 'Western', latitude: 19.0544, longitude: 72.8406 },
  { id: 'andheri', name: 'Andheri', line: 'Western', latitude: 19.1197, longitude: 72.8464 },
  { id: 'borivali', name: 'Borivali', line: 'Western', latitude: 19.2305, longitude: 72.8567 },
  
  // Harbour Line
  { id: 'csmth', name: 'CSMT', line: 'Harbour', latitude: 18.9398, longitude: 72.8355 },
  { id: 'vadala', name: 'Vadala Road', line: 'Harbour', latitude: 19.0154, longitude: 72.8562 },
  { id: 'gtb', name: 'GTB Nagar', line: 'Harbour', latitude: 19.0208, longitude: 72.8607 },
  { id: 'chembur', name: 'Chembur', line: 'Harbour', latitude: 19.0627, longitude: 72.8988 },
  { id: 'mankhurd', name: 'Mankhurd', line: 'Harbour', latitude: 19.0436, longitude: 72.9311 },
  { id: 'vashi', name: 'Vashi', line: 'Harbour', latitude: 19.0677, longitude: 72.9989 },
  { id: 'nerul', name: 'Nerul', line: 'Harbour', latitude: 19.0330, longitude: 73.0197 },
];

export const getLineColor = (line: TrainLine): string => {
  switch (line) {
    case 'Central':
      return '#F44336';
    case 'Western':
      return '#2196F3';
    case 'Harbour':
      return '#4CAF50';
  }
};

export const findNearestStation = (
  latitude: number,
  longitude: number
): Station | null => {
  if (MUMBAI_STATIONS.length === 0) return null;

  let nearest = MUMBAI_STATIONS[0];
  let minDistance = getDistance(latitude, longitude, nearest.latitude, nearest.longitude);

  for (const station of MUMBAI_STATIONS) {
    const distance = getDistance(latitude, longitude, station.latitude, station.longitude);
    if (distance < minDistance) {
      minDistance = distance;
      nearest = station;
    }
  }

  return nearest;
};

const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Earth's radius in km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const toRad = (deg: number): number => {
  return deg * (Math.PI / 180);
};
